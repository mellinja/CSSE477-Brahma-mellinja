package needyplugin;

import java.util.ArrayList;

import javax.swing.JLabel;

import plugin.IAudioExtender;

import plugin.Plugin;

public class DependentPlugin extends Plugin implements IAudioExtender {

	public String songTitle = "route-1.mid";
	public IAudioExtender audioFriend;
	public static final String PLUGIN_ID = "Music Changer";

	public DependentPlugin() {
		super(PLUGIN_ID);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void start() {
		songTitle = "opening.mid";
	}

	@Override
	public void stop() {
		songTitle = "route-1.mid";
	}

	@Override
	public void setOtherPlugins(ArrayList<Plugin> plugins) {
		
	}


	@Override
	public String getSongTitle() {
		return songTitle;
	}

}
