package textextension;

import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;

import plugin.ITextPlugin;
import plugin.Plugin;

public class MyTextPlugin extends Plugin implements ITextPlugin, Runnable{
	public static final String PLUGIN_ID = "Text Timer";
    private JLabel myLabel;
    private int count = 0;
    Thread mThread;
    public boolean stop = false;
	
	
	
	public MyTextPlugin() {
		super(PLUGIN_ID);
		myLabel = new JLabel();
		mThread = new Thread(this);
	}

	@Override
	public JLabel getTextLabel() {
		// TODO Auto-generated method stub
		return myLabel;
	}

	@Override
	public void start() {
		if( mThread.isAlive()){
			this.stop();
		}
		mThread.start();
		System.out.println("Thread started!!!!");
	}

	@Override
	public void stop() {
		mThread.stop();
		count = 0;
		mThread = new Thread(this);
	}

	@Override
	public void run() {
		for(;;){
			if (stop) return;
			myLabel.setText(""+count++);
			if (count > 1000000){
				count = 0;
			}
		    try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public void setOtherPlugins(ArrayList<Plugin> plugins) {
		// TODO Auto-generated method stub
		
	}

}
