package plugin;

public interface IAudioExtender {
	
	abstract public String getSongTitle();

}
