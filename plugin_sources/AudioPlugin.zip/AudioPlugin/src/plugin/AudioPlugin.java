package plugin;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;

import plugin.IAudioExtender;
import plugin.Plugin;

public class AudioPlugin extends Plugin{

	public static final String PLUGIN_ID = "Audio Plugin";

	public String songTitle = "route-1.mid";
	public IAudioExtender changer;
	public AudioPlugin() {
		super(PLUGIN_ID);
	}

	Sequencer sequencer;


	@Override
	public void start() {
		if(changer != null){
			songTitle = changer.getSongTitle();
		}
		try {
			// From file
			Sequence sequence = MidiSystem.getSequence(new File(songTitle));

			// Create a sequencer for the sequence
			sequencer = MidiSystem.getSequencer();
			sequencer.open();
			sequencer.setSequence(sequence);

			// Start playing
			sequencer.start();
		} catch (MalformedURLException e) {
			System.out.println("Error 1");
		} catch (IOException e) {
			System.out.println("Error 2");
		} catch (MidiUnavailableException e) {
			System.out.println("Error 3");
		} catch (InvalidMidiDataException e) {
			System.out.println("Error 4");
		}
	}

	@Override
	public void stop() {
		if (sequencer != null)
			sequencer.stop();
	}

	@Override
	public void setOtherPlugins(ArrayList<Plugin> plugins) {
		for(Plugin p:plugins){
			if (p instanceof plugin.IAudioExtender){
				changer = (IAudioExtender)p;
			}
		}
	}
	
	public String getSongTitle(){
		return "Pokemon R/B/Y Route 1 Theme";
	}

}
